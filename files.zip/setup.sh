#!/bin/bash
# PPAForge AI Installation Script
# This script sets up the complete environment for PPAForge AI

set -e  # Exit on error

echo "========================================"
echo "PPAForge AI - Installation Script"
echo "========================================"
echo ""

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[✓]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1"
}

# Check Python version
echo "Checking Python version..."
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d. -f1)
PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d. -f2)

if [ "$PYTHON_MAJOR" -lt 3 ] || { [ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 9 ]; }; then
    print_error "Python 3.9+ is required. Found: $PYTHON_VERSION"
    exit 1
fi
print_status "Python version: $PYTHON_VERSION"

# Check if running in virtual environment
if [ -z "$VIRTUAL_ENV" ]; then
    print_warning "Not running in a virtual environment"
    echo "Creating virtual environment..."
    python3 -m venv venv
    source venv/bin/activate
    print_status "Virtual environment created and activated"
else
    print_status "Running in virtual environment: $VIRTUAL_ENV"
fi

# Upgrade pip
echo ""
echo "Upgrading pip..."
pip install --upgrade pip setuptools wheel
print_status "pip upgraded"

# Install PyTorch (with CUDA support if available)
echo ""
echo "Installing PyTorch..."
if command -v nvidia-smi &> /dev/null; then
    print_status "CUDA detected, installing PyTorch with CUDA support"
    pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
else
    print_warning "CUDA not detected, installing CPU-only PyTorch"
    pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
fi
print_status "PyTorch installed"

# Install PyTorch Geometric
echo ""
echo "Installing PyTorch Geometric..."
pip install torch-scatter torch-sparse torch-cluster torch-spline-conv torch-geometric -f https://data.pyg.org/whl/torch-2.0.0+cu118.html
print_status "PyTorch Geometric installed"

# Install remaining requirements
echo ""
echo "Installing other dependencies..."
pip install -r requirements.txt
print_status "Dependencies installed"

# Create necessary directories
echo ""
echo "Creating project directories..."
mkdir -p data/benchmarks
mkdir -p data/processed
mkdir -p data/results
mkdir -p checkpoints
mkdir -p logs
mkdir -p results/figures
print_status "Directories created"

# Check for OpenROAD
echo ""
echo "Checking for OpenROAD..."
if command -v openroad &> /dev/null; then
    OPENROAD_VERSION=$(openroad -version 2>&1 | head -n 1)
    print_status "OpenROAD found: $OPENROAD_VERSION"
else
    print_warning "OpenROAD not found"
    echo "Please install OpenROAD from: https://github.com/The-OpenROAD-Project/OpenROAD"
    echo "Or run: ./scripts/install_openroad.sh"
fi

# Check for Sky130 PDK
echo ""
echo "Checking for Sky130 PDK..."
if [ -d "/usr/local/share/pdk/sky130A" ] || [ -d "$HOME/.volare/sky130A" ]; then
    print_status "Sky130 PDK found"
else
    print_warning "Sky130 PDK not found"
    echo "Please install Sky130 PDK from: https://github.com/google/skywater-pdk"
    echo "Or run: ./scripts/setup_sky130.sh"
fi

# Download example benchmarks (optional)
echo ""
read -p "Download example benchmark designs? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Downloading example designs..."
    
    # GCD (Greatest Common Divisor)
    mkdir -p data/benchmarks/gcd
    cat > data/benchmarks/gcd/design.v << 'EOF'
// Simple GCD design for testing
module gcd (
    input clk,
    input rst,
    input [7:0] a,
    input [7:0] b,
    output reg [7:0] result
);
    reg [7:0] x, y;
    
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            x <= 0;
            y <= 0;
            result <= 0;
        end else begin
            if (x == 0 && y == 0) begin
                x <= a;
                y <= b;
            end else if (x > y) begin
                x <= x - y;
            end else if (y > x) begin
                y <= y - x;
            end else begin
                result <= x;
            end
        end
    end
endmodule
EOF
    
    cat > data/benchmarks/gcd/constraints.sdc << 'EOF'
# Clock constraint
create_clock -name clk -period 10.0 [get_ports clk]
set_input_delay -clock clk 0.5 [all_inputs]
set_output_delay -clock clk 0.5 [all_outputs]
EOF
    
    print_status "Example designs downloaded"
fi

# Run tests
echo ""
read -p "Run tests to verify installation? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Running tests..."
    if pytest tests/ -v; then
        print_status "All tests passed!"
    else
        print_warning "Some tests failed, but installation is complete"
    fi
fi

# Summary
echo ""
echo "========================================"
echo "Installation Summary"
echo "========================================"
print_status "PPAForge AI installed successfully!"
echo ""
echo "Next steps:"
echo "  1. Configure paths in config/config.yaml"
echo "  2. Add your design files to data/benchmarks/"
echo "  3. Run training: python scripts/train.py --design data/benchmarks/gcd"
echo "  4. Or launch UI: streamlit run app/app.py"
echo ""
echo "For more information, see README.md"
echo "========================================"
